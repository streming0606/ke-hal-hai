require("dotenv").config({ path: "../.env" });
const express = require("express");
const cors = require("cors");
const Anthropic = require("@anthropic-ai/sdk");
const { createClient } = require("@supabase/supabase-js");
const { v4: uuidv4 } = require("uuid");

const app = express();
app.use(express.json());
app.use(cors({ origin: "*" }));

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

app.get("/api/health", (req, res) => res.json({ ok: true }));

app.post("/api/session", async (req, res) => {
  const { persona } = req.body;
  if (!persona) return res.status(400).json({ error: "persona required" });
  const sessionId = uuidv4();
  const { error } = await supabase
    .from("sessions")
    .insert({ id: sessionId, persona, created_at: new Date().toISOString() });
  if (error) return res.status(500).json({ error: error.message });
  res.json({ sessionId });
});

app.get("/api/sessions", async (req, res) => {
  const { data, error } = await supabase
    .from("sessions")
    .select("id, persona, created_at")
    .order("created_at", { ascending: false })
    .limit(20);
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.get("/api/session/:id/messages", async (req, res) => {
  const { data, error } = await supabase
    .from("messages")
    .select("*")
    .eq("session_id", req.params.id)
    .order("created_at", { ascending: true });
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.post("/api/chat", async (req, res) => {
  const { sessionId, userMessage } = req.body;
  if (!sessionId || !userMessage)
    return res.status(400).json({ error: "sessionId and userMessage required" });

  const { data: session, error: sErr } = await supabase
    .from("sessions")
    .select("persona")
    .eq("id", sessionId)
    .single();
  if (sErr || !session) return res.status(404).json({ error: "Session not found" });

  const { data: history } = await supabase
    .from("messages")
    .select("role, content")
    .eq("session_id", sessionId)
    .order("created_at", { ascending: true });

  const messages = (history || []).map((m) => ({
    role: m.role,
    content: m.role === "assistant"
      ? m.content.split("---CORRECTIONS---")[0].trim()
      : m.content,
  }));
  messages.push({ role: "user", content: userMessage });

  const systemPrompt = `You are playing the role of: ${session.persona}.

Your job:
1. Respond IN CHARACTER as ${session.persona}. Be realistic and challenging. Ask follow-up questions. Push back when appropriate. Do NOT be easy.
2. After your reply, write exactly "---CORRECTIONS---" on a new line, then give honest direct feedback on the user's English — grammar errors, wrong word choice, unnatural phrasing. If their English was perfect, write "No corrections needed." Be harsh but constructive. Never sugarcoat mistakes.

EXACT format:
[Your in-character reply here]
---CORRECTIONS---
[Your corrections here]`;

  try {
    await supabase.from("messages").insert({
      session_id: sessionId,
      role: "user",
      content: userMessage,
      created_at: new Date().toISOString(),
    });

    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 1024,
      system: systemPrompt,
      messages,
    });

    const fullReply = response.content[0].text;
    const parts = fullReply.split("---CORRECTIONS---");
    const aiReply = parts[0].trim();
    const corrections = parts[1] ? parts[1].trim() : null;

    await supabase.from("messages").insert({
      session_id: sessionId,
      role: "assistant",
      content: fullReply,
      created_at: new Date().toISOString(),
    });

    res.json({ reply: aiReply, corrections });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "AI call failed: " + err.message });
  }
});

app.delete("/api/session/:id", async (req, res) => {
  await supabase.from("messages").delete().eq("session_id", req.params.id);
  await supabase.from("sessions").delete().eq("id", req.params.id);
  res.json({ ok: true });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
