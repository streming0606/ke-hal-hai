import React, { useState, useEffect, useRef } from "react";

const API = import.meta.env.VITE_API_URL || "";

const PERSONAS = [
  { label: "Job Interviewer", value: "strict job interviewer at a top tech company. Ask tough questions, push back on vague answers, evaluate communication skills." },
  { label: "Business Consultant", value: "experienced McKinsey-style business consultant. Be direct, challenge assumptions, ask for data and specifics." },
  { label: "Best Friend", value: "close friend who speaks casually and naturally. Have real conversations, joke around, but gently correct English mistakes." },
  { label: "English Teacher", value: "strict but encouraging English teacher. Focus heavily on grammar, pronunciation tips, and natural phrasing. Correct every mistake." },
  { label: "VC Investor", value: "tough venture capital investor evaluating a startup pitch. Ask hard questions about market, revenue, and competition." },
  { label: "Immigration Officer", value: "airport immigration officer. Ask standard but probing questions about purpose of travel, stay duration, finances." },
];

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

export default function App() {
  const [screen, setScreen] = useState("home");
  const [sessions, setSessions] = useState([]);
  const [currentSession, setCurrentSession] = useState(null);
  const [messages, setMessages] = useState([]);
  const [persona, setPersona] = useState("");
  const [customPersona, setCustomPersona] = useState("");
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState("");
  const [corrections, setCorrections] = useState(null);
  const [isListening, setIsListening] = useState(false);
  const [ttsOn, setTtsOn] = useState(true);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const chatRef = useRef(null);
  const recogRef = useRef(null);

  useEffect(() => { loadSessions(); }, []);
  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [messages]);

  async function loadSessions() {
    try {
      const res = await fetch(`${API}/api/sessions`);
      const data = await res.json();
      setSessions(Array.isArray(data) ? data : []);
    } catch { setSessions([]); }
  }

  async function startSession(p) {
    if (!p.trim()) return;
    setLoading(true);
    setStatus("Starting session...");
    try {
      const res = await fetch(`${API}/api/session`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ persona: p }),
      });
      const data = await res.json();
      if (data.sessionId) {
        setCurrentSession({ id: data.sessionId, persona: p });
        setMessages([{ role: "ai", text: `Role set. I am now your ${p}. Start speaking or typing.` }]);
        setCorrections(null);
        setScreen("chat");
        setStatus("Ready");
        loadSessions();
        if (ttsOn) speak(`Role set. I am now your ${p}. Start speaking or typing.`);
      }
    } catch { setStatus("Connection error — is server running?"); }
    setLoading(false);
  }

  async function loadSession(s) {
    setCurrentSession(s);
    setLoading(true);
    setStatus("Loading history...");
    try {
      const res = await fetch(`${API}/api/session/${s.id}/messages`);
      const data = await res.json();
      const msgs = (data || []).map((m) => ({
        role: m.role === "user" ? "user" : "ai",
        text: m.role === "assistant"
          ? m.content.split("---CORRECTIONS---")[0].trim()
          : m.content,
      }));
      setMessages(msgs);
      setCorrections(null);
      setScreen("chat");
      setStatus("Ready");
    } catch { setStatus("Failed to load history"); }
    setLoading(false);
  }

  async function sendMessage() {
    const text = input.trim();
    if (!text || !currentSession || loading) return;
    stopSpeaking();
    setInput("");
    setMessages((prev) => [...prev, { role: "user", text }]);
    setCorrections(null);
    setLoading(true);
    setStatus("AI is thinking...");
    try {
      const res = await fetch(`${API}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId: currentSession.id, userMessage: text }),
      });
      const data = await res.json();
      if (data.reply) {
        setMessages((prev) => [...prev, { role: "ai", text: data.reply }]);
        if (data.corrections && data.corrections.toLowerCase() !== "no corrections needed.") {
          setCorrections(data.corrections);
        }
        setStatus("Ready");
        if (ttsOn) speak(data.reply);
      } else {
        setStatus("Error: " + (data.error || "Unknown error"));
      }
    } catch { setStatus("Network error — check connection"); }
    setLoading(false);
  }

  async function deleteSession(id, e) {
    e.stopPropagation();
    await fetch(`${API}/api/session/${id}`, { method: "DELETE" });
    loadSessions();
    if (currentSession?.id === id) { setScreen("home"); setCurrentSession(null); }
  }

  function toggleMic() {
    if (!SpeechRecognition) { setStatus("Voice not supported — use Chrome"); return; }
    if (isListening) { recogRef.current?.stop(); return; }
    stopSpeaking();
    const r = new SpeechRecognition();
    r.lang = "en-US";
    r.interimResults = true;
    r.continuous = false;
    r.onstart = () => { setIsListening(true); setStatus("Listening... tap mic to stop"); };
    r.onresult = (e) => {
      let final = "", interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) final += e.results[i][0].transcript;
        else interim += e.results[i][0].transcript;
      }
      setInput(final || interim);
    };
    r.onerror = (e) => { setStatus("Mic error: " + e.error); setIsListening(false); };
    r.onend = () => {
      setIsListening(false);
      setStatus("Ready");
      setTimeout(() => {
        setInput((cur) => { if (cur.trim()) { sendWithText(cur.trim()); } return cur; });
      }, 300);
    };
    recogRef.current = r;
    r.start();
  }

  function sendWithText(text) {
    if (!text || !currentSession || loading) return;
    stopSpeaking();
    setInput("");
    setMessages((prev) => [...prev, { role: "user", text }]);
    setCorrections(null);
    setLoading(true);
    setStatus("AI is thinking...");
    fetch(`${API}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId: currentSession.id, userMessage: text }),
    })
      .then((r) => r.json())
      .then((data) => {
        if (data.reply) {
          setMessages((prev) => [...prev, { role: "ai", text: data.reply }]);
          if (data.corrections && data.corrections.toLowerCase() !== "no corrections needed.") {
            setCorrections(data.corrections);
          }
          setStatus("Ready");
          if (ttsOn) speak(data.reply);
        } else setStatus("Error: " + (data.error || "Unknown"));
        setLoading(false);
      })
      .catch(() => { setStatus("Network error"); setLoading(false); });
  }

  function speak(text) {
    if (!window.speechSynthesis) return;
    stopSpeaking();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "en-US"; u.rate = 0.92; u.pitch = 1;
    u.onstart = () => setIsSpeaking(true);
    u.onend = () => setIsSpeaking(false);
    u.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(u);
  }

  function stopSpeaking() {
    window.speechSynthesis?.cancel();
    setIsSpeaking(false);
  }

  function formatTime(iso) {
    const d = new Date(iso);
    return d.toLocaleDateString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
  }

  if (screen === "home") return (
    <div style={s.page}>
      <div style={s.container}>
        <div style={s.header}>
          <div style={s.logo}>🎙️</div>
          <h1 style={s.title}>Speaking Partner</h1>
          <p style={s.subtitle}>Set a role, then talk in English</p>
        </div>

        <div style={s.card}>
          <p style={s.label}>Quick roles</p>
          <div style={s.chips}>
            {PERSONAS.map((p) => (
              <button key={p.label} style={{...s.chip, ...(persona === p.value ? s.chipActive : {})}}
                onClick={() => setPersona(p.value)}>
                {p.label}
              </button>
            ))}
          </div>
          <p style={{...s.label, marginTop: 16}}>Or write your own role</p>
          <textarea
            style={{...s.input, height: 72, resize: "none", padding: "10px 12px"}}
            placeholder='e.g. "aggressive startup founder who thinks my idea is bad"'
            value={customPersona}
            onChange={(e) => { setCustomPersona(e.target.value); setPersona(e.target.value); }}
          />
          <button
            style={{...s.btn, marginTop: 12, width: "100%", background: "#6c63ff", color: "#fff"}}
            onClick={() => startSession(persona)}
            disabled={!persona.trim() || loading}>
            {loading ? "Starting..." : "Start conversation →"}
          </button>
          {status && <p style={s.statusText}>{status}</p>}
        </div>

        {sessions.length > 0 && (
          <div style={s.card}>
            <p style={s.label}>Past sessions</p>
            {sessions.map((s_) => (
              <div key={s_.id} style={s.sessionRow} onClick={() => loadSession(s_)}>
                <div style={{flex: 1}}>
                  <p style={{fontSize: 14, color: "var(--text)", marginBottom: 2}}>{s_.persona.slice(0, 60)}{s_.persona.length > 60 ? "…" : ""}</p>
                  <p style={{fontSize: 12, color: "var(--text2)"}}>{formatTime(s_.created_at)}</p>
                </div>
                <button style={s.deleteBtn} onClick={(e) => deleteSession(s_.id, e)}>✕</button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div style={s.page}>
      <div style={s.container}>
        <div style={s.chatHeader}>
          <button style={s.backBtn} onClick={() => { stopSpeaking(); setScreen("home"); loadSessions(); }}>← Back</button>
          <div style={{flex: 1, minWidth: 0}}>
            <p style={{fontSize: 13, color: "var(--text2)", marginBottom: 1}}>Talking to</p>
            <p style={{fontSize: 14, fontWeight: 600, color: "var(--text)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis"}}>
              {currentSession?.persona?.slice(0, 50)}
            </p>
          </div>
          <div style={{display: "flex", alignItems: "center", gap: 8}}>
            {isSpeaking && <span style={{fontSize: 12, color: "#6c63ff"}}>🔊</span>}
            <button style={{...s.chip, padding: "4px 10px", fontSize: 12, background: ttsOn ? "#6c63ff22" : "transparent", color: ttsOn ? "#6c63ff" : "var(--text2)"}}
              onClick={() => { if (ttsOn) stopSpeaking(); setTtsOn(!ttsOn); }}>
              {ttsOn ? "Voice on" : "Voice off"}
            </button>
          </div>
        </div>

        <div style={s.chatBox} ref={chatRef}>
          {messages.map((m, i) => (
            <div key={i} style={{display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start"}}>
              <div style={m.role === "user" ? s.bubbleUser : s.bubbleAi}>
                {m.text}
              </div>
            </div>
          ))}
          {loading && (
            <div style={{display: "flex", justifyContent: "flex-start"}}>
              <div style={{...s.bubbleAi, color: "var(--text2)"}}>typing…</div>
            </div>
          )}
        </div>

        {corrections && (
          <div style={s.corrections}>
            <p style={{fontSize: 12, fontWeight: 600, color: "#f59e0b", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em"}}>
              ✏️ Corrections
            </p>
            <p style={{fontSize: 13, color: "var(--text)", lineHeight: 1.6}}>{corrections}</p>
            <button style={{marginTop: 8, fontSize: 12, color: "var(--text2)", background: "transparent", padding: 0}}
              onClick={() => setCorrections(null)}>dismiss</button>
          </div>
        )}

        <div style={s.statusBar}>
          <span style={{width: 7, height: 7, borderRadius: "50%", background: loading ? "#f59e0b" : isListening ? "#ef4444" : "#22c55e", flexShrink: 0, display: "inline-block"}}></span>
          <span style={{fontSize: 12, color: "var(--text2)"}}>{status || "Ready"}</span>
        </div>

        <div style={s.inputRow}>
          <button style={{...s.micBtn, background: isListening ? "#ef444422" : "var(--surface2)", border: `1px solid ${isListening ? "#ef4444" : "var(--border)"}`}}
            onClick={toggleMic} title="Tap to speak">
            <span style={{fontSize: 20}}>{isListening ? "⏹" : "🎙️"}</span>
          </button>
          <textarea
            style={{...s.input, flex: 1, height: 48, resize: "none", padding: "12px 14px"}}
            placeholder="Type here or tap mic…"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
          />
          <button style={{...s.micBtn, background: "#6c63ff", border: "none"}}
            onClick={sendMessage} disabled={!input.trim() || loading}>
            <span style={{fontSize: 20, color: "#fff"}}>↑</span>
          </button>
        </div>
      </div>
    </div>
  );
}

const s = {
  page: { minHeight: "100vh", background: "var(--bg)", padding: "16px 0 32px" },
  container: { maxWidth: 480, margin: "0 auto", padding: "0 16px" },
  header: { textAlign: "center", padding: "24px 0 20px" },
  logo: { fontSize: 40, marginBottom: 8 },
  title: { fontSize: 24, fontWeight: 700, color: "var(--text)", marginBottom: 4 },
  subtitle: { fontSize: 14, color: "var(--text2)" },
  card: { background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 14, padding: 16, marginBottom: 16 },
  label: { fontSize: 12, fontWeight: 600, color: "var(--text2)", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 10 },
  chips: { display: "flex", flexWrap: "wrap", gap: 8 },
  chip: { padding: "6px 12px", borderRadius: 20, border: "1px solid var(--border)", background: "var(--surface2)", color: "var(--text)", fontSize: 13 },
  chipActive: { borderColor: "#6c63ff", background: "#6c63ff22", color: "#8b85ff" },
  input: { width: "100%", padding: "10px 12px", borderRadius: 10, border: "1px solid var(--border)", background: "var(--surface2)", color: "var(--text)", fontSize: 14 },
  btn: { padding: "12px 20px", borderRadius: 10, fontWeight: 600, fontSize: 15 },
  statusText: { marginTop: 10, fontSize: 13, color: "var(--text2)", textAlign: "center" },
  sessionRow: { display: "flex", alignItems: "center", gap: 12, padding: "10px 0", borderBottom: "1px solid var(--border)", cursor: "pointer" },
  deleteBtn: { width: 28, height: 28, borderRadius: 6, background: "transparent", border: "1px solid var(--border)", color: "var(--text2)", fontSize: 12, flexShrink: 0 },
  chatHeader: { display: "flex", alignItems: "center", gap: 12, padding: "12px 0 16px", borderBottom: "1px solid var(--border)", marginBottom: 12 },
  backBtn: { background: "var(--surface2)", border: "1px solid var(--border)", color: "var(--text)", padding: "6px 12px", borderRadius: 8, fontSize: 13, flexShrink: 0 },
  chatBox: { minHeight: 320, maxHeight: "calc(100vh - 340px)", overflowY: "auto", display: "flex", flexDirection: "column", gap: 10, paddingBottom: 8 },
  bubbleUser: { maxWidth: "80%", padding: "10px 14px", borderRadius: "14px 14px 4px 14px", background: "#6c63ff", color: "#fff", fontSize: 14, lineHeight: 1.5 },
  bubbleAi: { maxWidth: "80%", padding: "10px 14px", borderRadius: "14px 14px 14px 4px", background: "var(--surface)", border: "1px solid var(--border)", color: "var(--text)", fontSize: 14, lineHeight: 1.5 },
  corrections: { background: "#1c1500", border: "1px solid #3d2f00", borderRadius: 10, padding: "12px 14px", margin: "8px 0" },
  statusBar: { display: "flex", alignItems: "center", gap: 8, padding: "6px 0", marginBottom: 6 },
  inputRow: { display: "flex", gap: 8, alignItems: "flex-end" },
  micBtn: { width: 48, height: 48, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 },
};
